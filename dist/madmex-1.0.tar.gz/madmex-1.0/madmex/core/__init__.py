'''
madmex.core
Core package.
'''
