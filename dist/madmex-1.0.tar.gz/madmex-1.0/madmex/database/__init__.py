'''
madmex.database

Database manager package. All database interactionshould be done through
the classes in this package.
'''
