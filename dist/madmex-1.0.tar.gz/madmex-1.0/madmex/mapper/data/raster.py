'''
Created on 11/06/2015

@author: erickpalacios
'''

class Raster(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        