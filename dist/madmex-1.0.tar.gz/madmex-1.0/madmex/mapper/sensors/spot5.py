'''
Created on 10/06/2015

@author: erickpalacios
'''
from madmex.core.controller.base import BaseCommand

class Command(BaseCommand):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        