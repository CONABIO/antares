'''
Created on 15/06/2015

@author: erickpalacios
'''

class Processes(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
    
    def create_output_name(self):
        pass
    
    def extract(self):
        pass
    
    def execute(self):
        pass
    
    def parser(self):
        pass
        
    def __str__(self):
        pass
        